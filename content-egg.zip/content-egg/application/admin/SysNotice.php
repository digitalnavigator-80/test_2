<?php

namespace ContentEgg\application\admin;

use ContentEgg\application\Plugin;

use function ContentEgg\prnx;

defined('\ABSPATH') || exit;

/**
 * SysNotice class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2025 keywordrush.com
 */
class SysNotice
{
    public function __construct()
    {
        \add_action('admin_notices', array($this, 'displayStatusNotice'));
        \add_action('template_redirect', array($this, 'sendStatusEmail'));
    }

    public function displayStatusNotice()
    {
    }

    public function sendStatusEmail()
    {
    }

    private function sendWarningEmail()
    {
    }

    public static function setMailContentType()
    {
        return 'text/html';
    }
}
