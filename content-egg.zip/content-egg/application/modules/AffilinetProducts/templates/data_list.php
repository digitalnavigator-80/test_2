<?php

/*
  Name: List
 */
__( 'List', 'content-egg-tpl' );

$this->renderPartial( 'list' );
