<?php

defined( '\ABSPATH' ) || exit;
/*
  Name: List
 */
__( 'List', 'content-egg-tpl' );

$this->renderPartial( 'list' );
