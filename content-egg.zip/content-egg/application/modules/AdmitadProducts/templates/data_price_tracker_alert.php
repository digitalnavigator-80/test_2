<?php

defined( '\ABSPATH' ) || exit;
/*
  Name: Price tracker & alert
 */

__( 'Price tracker & alert', 'content-egg-tpl' );

$this->renderPartial( 'price_tracker_alert' );
