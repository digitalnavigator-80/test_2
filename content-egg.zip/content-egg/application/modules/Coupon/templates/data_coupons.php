<?php

defined( '\ABSPATH' ) || exit;

/*
  Name: Coupons
 */
__( 'Coupons', 'content-egg-tpl' );


$this->renderPartial( 'coupon' );
